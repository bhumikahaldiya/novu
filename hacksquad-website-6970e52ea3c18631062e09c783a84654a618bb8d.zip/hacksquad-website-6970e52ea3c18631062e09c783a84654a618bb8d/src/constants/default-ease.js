const DEFAULT_EASE = [0.5, 0.5, 0.5, 1];

export default DEFAULT_EASE;

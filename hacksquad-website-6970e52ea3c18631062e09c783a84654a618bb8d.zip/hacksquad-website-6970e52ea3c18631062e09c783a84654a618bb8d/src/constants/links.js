export default {
  my_team: {
    href: '/myteam',
  },
  leaderboard: {
    href: '/leaderboard',
  },
  sponsors: {
    href: '/#sponsors',
  },
  events: {
    href: '/#events',
  },
  swag: {
    href: '/#swag',
  },
  qa: {
    href: '/#qa',
  },
};

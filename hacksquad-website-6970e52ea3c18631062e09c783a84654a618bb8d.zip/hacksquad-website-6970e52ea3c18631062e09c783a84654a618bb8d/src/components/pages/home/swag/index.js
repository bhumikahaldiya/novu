export { default } from './swag';

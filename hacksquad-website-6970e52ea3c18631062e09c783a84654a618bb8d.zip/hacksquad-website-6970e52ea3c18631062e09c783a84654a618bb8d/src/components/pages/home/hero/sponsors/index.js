export { default } from './sponsors';

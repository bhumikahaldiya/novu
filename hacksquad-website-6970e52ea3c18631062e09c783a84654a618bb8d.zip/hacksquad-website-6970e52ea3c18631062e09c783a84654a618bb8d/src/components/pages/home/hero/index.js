export { default } from './hero';

export { default } from './question-and-answer';

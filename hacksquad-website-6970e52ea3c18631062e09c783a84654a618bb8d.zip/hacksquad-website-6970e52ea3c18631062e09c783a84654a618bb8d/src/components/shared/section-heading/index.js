export { default } from './section-heading';

export { default } from './seo';

import 'styles/main.css';

// eslint-disable-next-line react/prop-types
const MyApp = ({ Component, pageProps }) => <Component {...pageProps} />;

export default MyApp;
